'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState, useCallback } from 'react';
import { useSaoSound } from '@/hooks/useSaoSound';
import { useImagePreload, SAO_CRITICAL_IMAGES } from '@/hooks/useImagePreload';
import SaoHUD, { type BarValue } from './SaoHUD';
import SaoMainMenu from './SaoMainMenu';
import SaoNotificationWindow, {
  type SaoNotificationData,
} from './SaoNotificationWindow';
import CharacterPanel from './CharacterPanel';
import SaoPanel from './SaoPanel';
import FloorPanel from './FloorPanel';
import ExplorePanel from './ExplorePanel';
import JournalPanel from './JournalPanel';
import { ExploreErrorBoundary } from './ExploreErrorBoundary';
import { getStartingPlayerStats, type PlayerStats, type Gender } from '@/lib/sao-data';
import { calcMaxHp, calcMaxMp, calcMaxSp } from '@/lib/sao-stats-engine';
import { SAMPLE_ITEMS } from '@/lib/sao-sample-items';
import type { Item, EquipmentState } from '@/lib/sao-inventory-types';
import { BAG_MAX_ITEMS, isTwoHanded, getEquipmentSlot } from '@/lib/sao-inventory-types';

interface GameScreenProps {
  playerName: string;
  gender: Gender;
  isAdmin?: boolean;
  onExit?: () => void;
}

/**
 * SAO Game Screen — the in-game UI.
 *
 * Layout:
 *   - Background: Aincrad.png
 *   - Top-left: SaoHUD (HP / MP / Energy + LV badge)
 *   - Top-right: SaoMainMenu (single icon → cascading menu)
 *   - Bottom-right: skill quick-slot row
 *   - Center: SaoNotificationWindow (modal-style, using the canonical
 *     3-layer SVG window from "Finestra notifiche SAO")
 *
 * All visual assets come EXCLUSIVELY from the asset-gioco-di-SAO repo.
 * No graphics are invented — only existing SVG/PNG assets are stacked.
 *
 * Audio: ambient sounds on mount, click feedback on every interaction.
 *
 * NOTE: bars do NOT auto-drain anymore. They only change via user actions
 * (menu clicks, etc.) or future combat events.
 */

export default function GameScreen({ playerName, gender, isAdmin = false, onExit }: GameScreenProps) {
  const { play } = useSaoSound();
  // Preload all critical game images at mount to eliminate lag/flicker
  useImagePreload(SAO_CRITICAL_IMAGES);
  const [stats] = useState<PlayerStats>(getStartingPlayerStats());
  const level = 1;
  // HP/MP/Energy are computed from level + stats using the SAO stats engine
  const maxHp = calcMaxHp(level, stats.vit);
  const maxMp = calcMaxMp(level, stats.men);
  const maxSp = calcMaxSp(level, stats.res);
  const [hp, setHp] = useState<BarValue>({ current: maxHp, max: maxHp });
  const [mp, setMp] = useState<BarValue>({ current: maxMp, max: maxMp });
  const [energy, setEnergy] = useState<BarValue>({ current: maxSp, max: maxSp });
  const [notification, setNotification] = useState<SaoNotificationData | null>(null);
  const [showWelcome, setShowWelcome] = useState(true);
  const [showCharacterPanel, setShowCharacterPanel] = useState(false);
  const [showBagPanel, setShowBagPanel] = useState(false);
  const [showInventoryPanel, setShowInventoryPanel] = useState(false);
  const [showFloorPanel, setShowFloorPanel] = useState(false);
  const [showExplorePanel, setShowExplorePanel] = useState(false);
  const [showJournalPanel, setShowJournalPanel] = useState(false);
  const [exploreAreaId, setExploreAreaId] = useState<string>('grandi-pianure');
  const [showCheatPanel, setShowCheatPanel] = useState(false);
  const [cheats, setCheats] = useState({
    skipEvents: false,
    immortal: false,
    instakill: false,
    infiniteCol: false,
  });
  const [items, setItems] = useState<Item[]>(SAMPLE_ITEMS);
  const [equipment, setEquipment] = useState<EquipmentState>({
    weapon: null,
    shield: null,
    armor: null,
    accessory1: null,
    accessory2: null,
  });
  const [xp] = useState<number>(0); // absolute XP value

  const pushNotification = useCallback(
    (n: Omit<SaoNotificationData, 'id'>) => {
      const full: SaoNotificationData = { ...n, id: Date.now() };
      setNotification(full);
      // Play the kind-specific alert sound (immediately, before the window
      // animation sound which fires after 300ms)
      const soundMap = {
        system: 'system' as const,
        message: 'message' as const,
        alert: 'alert' as const,
        present: 'present' as const,
      };
      play(soundMap[n.kind], 0.4);
    },
    [play],
  );

  // Boot sequence — show a welcome notification
  useEffect(() => {
    play('popupPanel', 0.4);
    const t1 = setTimeout(() => {
      play('welcome', 0.4);
      pushNotification({
        kind: 'system',
        title: 'Sistema',
        body: `Benvenuto ad Aincrad, ${playerName}. Sei al Floor 1.`,
        autoDismiss: 6000,
      });
    }, 800);
    const t3 = setTimeout(() => setShowWelcome(false), 3000);
    return () => {
      clearTimeout(t1);
      clearTimeout(t3);
    };
  }, [play, playerName, pushNotification]);

  const handleMenuClick = (id: string) => {
    switch (id) {
      case 'character':
        // Open the character panel (instead of a simple notification)
        play('popupPanel', 0.4);
        setShowCharacterPanel(true);
        break;
      case 'wallet':
        play('popupPanel', 0.4);
        setShowBagPanel(true);
        break;
      case 'inventory':
        play('popupPanel', 0.4);
        setShowInventoryPanel(true);
        break;
      case 'quest':
        pushNotification({
          kind: 'message',
          title: 'Quest',
          body: 'Nessuna quest attiva. Visita la città di inizi per ricevere missioni.',
          autoDismiss: 6000,
        });
        break;
      case 'floor':
        play('popupPanel', 0.4);
        setShowFloorPanel(true);
        break;
      case 'party':
        pushNotification({
          kind: 'message',
          title: 'Party',
          body: 'Non sei in un party. Invita altri giocatori per formarlo.',
          autoDismiss: 6000,
        });
        break;
      case 'diario':
        play('popupPanel', 0.4);
        setShowJournalPanel(true);
        break;
      case 'options':
        pushNotification({
          kind: 'present',
          title: 'Opzioni',
          body: 'Sistema NerveGear v1.100 — funzionamento ottimale.',
          autoDismiss: 6000,
        });
        break;
      case 'messages':
        pushNotification({
          kind: 'message',
          title: 'Messaggi',
          body: 'Nessun nuovo messaggio.',
          autoDismiss: 6000,
        });
        break;
      default:
        break;
    }
  };

  const handleLogout = () => {
    pushNotification({
      kind: 'alert',
      title: 'Log Out',
      body: 'Vuoi davvero scollegarti da Aincrad? Verrai riportato alla schermata di login.',
      autoDismiss: 0, // manual dismissal only
    });
    // After confirm, the onConfirm handler will trigger onExit
  };

  const handleConfirm = (_id: number) => {
    if (notification?.title === 'Log Out') {
      // Logout confirmed
      play('dismissLauncher', 0.4);
      setTimeout(() => onExit?.(), 200);
      return;
    }
    setNotification(null);
  };

  const handleCancel = (_id: number) => {
    setNotification(null);
  };

  // === Equipment logic ===
  const handleEquip = (item: Item) => {
    setEquipment((prev) => {
      const next = { ...prev };
      if (item.category === 'accessory') {
        if (!prev.accessory1) next.accessory1 = item.id;
        else if (!prev.accessory2) next.accessory2 = item.id;
        else next.accessory1 = item.id;
      } else {
        const slot = getEquipmentSlot(item);
        if (slot && slot !== 'accessory1' && slot !== 'accessory2') {
          (next as Record<string, string | null>)[slot] = item.id;
        }
      }
      if (isTwoHanded(item)) next.shield = null;
      return next;
    });
  };

  const handleMoveToBag = (item: Item) => {
    const bagCount = items.filter((i) => i.location === 'bag').length;
    if (bagCount >= BAG_MAX_ITEMS) {
      pushNotification({
        kind: 'alert',
        title: 'Borsa Piena',
        body: `La borsa pu\u00f2 contenere massimo ${BAG_MAX_ITEMS} oggetti.`,
        autoDismiss: 4000,
      });
      return;
    }
    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, location: 'bag' as const } : i))
    );
    play('click', 0.4);
  };

  const handleMoveToInventory = (item: Item) => {
    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, location: 'inventory' as const } : i))
    );
    play('click', 0.4);
  };

  return (
    <motion.div
      className="fixed inset-0 overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
    >
      {/* ===== Background: Aincrad ===== */}
      <div className="absolute inset-0 -z-20">
        <img
          src="/sao/backgrounds/Aincrad.png"
          alt="Aincrad"
          className="w-full h-full object-cover"
          style={{ filter: 'brightness(0.65) saturate(1.1)' }}
          draggable={false}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(180deg, rgba(2,8,20,0.7) 0%, rgba(2,8,20,0.2) 30%, rgba(2,8,20,0.2) 70%, rgba(2,8,20,0.8) 100%)',
          }}
        />
      </div>

      {/* ===== Cheat button (admin only) — below menu icon ===== */}
      {isAdmin && (
        <button
          onClick={() => { play('click', 0.3); setShowCheatPanel(!showCheatPanel); }}
          className="fixed top-16 right-4 z-30 px-3 py-1.5"
          style={{
            background: showCheatPanel ? 'rgba(190, 33, 86, 0.8)' : 'rgba(8, 12, 20, 0.6)',
            border: '1px solid rgba(190, 33, 86, 0.5)',
            clipPath: 'polygon(5px 0, 100% 0, 100% calc(100% - 5px), calc(100% - 5px) 100%, 0 100%, 0 5px)',
            color: showCheatPanel ? '#FBFBFB' : 'rgba(190, 33, 86, 0.7)',
            fontFamily: "'SAO UI', 'Trebuchet MS', sans-serif",
            fontWeight: 400, fontSize: '0.6rem', letterSpacing: '0.2em',
            cursor: 'pointer',
            backdropFilter: 'blur(4px)',
          }}
        >
          CHEAT
        </button>
      )}

      {/* ===== Cheat panel (admin only) ===== */}
      {isAdmin && showCheatPanel && (
        <div
          className="fixed top-24 right-4 z-30 p-4"
          style={{
            background: 'rgba(8, 12, 20, 0.85)',
            border: '1px solid rgba(190, 33, 86, 0.4)',
            clipPath: 'polygon(8px 0, 100% 0, 100% calc(100% - 8px), calc(100% - 8px) 100%, 0 100%, 0 8px)',
            backdropFilter: 'blur(8px)',
            minWidth: '220px',
          }}
        >
          <p
            className="tracking-[0.3em] mb-3 text-center"
            style={{ color: '#BE2156', fontFamily: "'SAO UI', 'Trebuchet MS', sans-serif", fontWeight: 400, fontSize: '0.7rem' }}
          >
            CHEAT ADMIN
          </p>
          {[
            { key: 'skipEvents' as const, label: 'Salta eventi zona' },
            { key: 'immortal' as const, label: 'Immortalità' },
            { key: 'instakill' as const, label: 'Instakill' },
            { key: 'infiniteCol' as const, label: 'Col infiniti' },
          ].map(({ key, label }) => (
            <label
              key={key}
              className="flex items-center gap-2 cursor-pointer mb-2"
              style={{ color: '#FBFBFB', fontFamily: "'SAO UI', 'Trebuchet MS', sans-serif", fontWeight: 400, fontSize: '0.7rem' }}
            >
              <input
                type="checkbox"
                checked={cheats[key]}
                onChange={(e) => {
                  setCheats({ ...cheats, [key]: e.target.checked });
                  play('click', 0.3);
                }}
                style={{ accentColor: '#BE2156', width: '16px', height: '16px', cursor: 'pointer' }}
              />
              {label}
            </label>
          ))}
        </div>
      )}

      {/* ===== HUD (top-left) ===== */}
      <SaoHUD hp={hp} mp={mp} energy={energy} level={1} playerName={playerName} />

      {/* ===== Main Menu (top-right, single icon → cascading menu) ===== */}
      <SaoMainMenu onItemClick={handleMenuClick} onLogout={handleLogout} />

      {/* ===== Welcome splash (brief, fades out) ===== */}
      <AnimatePresence>
        {showWelcome && (
          <motion.div
            className="fixed inset-0 flex items-center justify-center pointer-events-none z-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.div
              className="text-center"
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            >
              <motion.p
                className="tracking-[0.4em]"
                style={{
                  fontSize: 'clamp(1rem, 3vw, 2rem)',
                  color: '#FBFBFB',
                  fontFamily: "'SAO UI', 'Trebuchet MS', sans-serif",
                  fontWeight: 400,
                  textShadow:
                    '0 0 20px rgba(43, 115, 179, 0.9), 0 0 40px rgba(43, 115, 179, 0.5)',
                }}
                animate={{ opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                FLOOR 1 — AINCRAD
              </motion.p>
              <motion.p
                className="tracking-[0.3em] mt-2 text-sm"
                style={{
                  color: '#5CC4F0',
                  fontFamily: "'SAO UI', 'Trebuchet MS', sans-serif",
                  fontWeight: 400,
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                BENVENUTO, {playerName.toUpperCase()}
              </motion.p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== Indicatore verde (bottom-center) — ruota come gli oggetti ===== */}
      <motion.div
        className="fixed bottom-8 left-1/2 -translate-x-1/2 z-20 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.85 }}
        transition={{ delay: 1, duration: 1 }}
      >
        <motion.img
          src="/sao/indicatore verde.svg"
          alt=""
          className="w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28"
          style={{ filter: 'drop-shadow(0 0 12px rgba(127, 197, 34, 0.6))' }}
          draggable={false}
          initial={{ rotateY: 0 }}
          animate={{ rotateY: 360 }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'linear',
          }}
        />
      </motion.div>

      {/* ===== Canonical SAO notification window (modal overlay) ===== */}
      <SaoNotificationWindow
        notification={notification}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />

      {/* ===== Character Panel (shown when "Personaggio" is clicked) ===== */}
      <CharacterPanel
        open={showCharacterPanel}
        onClose={() => setShowCharacterPanel(false)}
        playerName={playerName}
        gender={gender}
        level={level}
        stats={stats}
        xp={xp}
        equipment={equipment}
        allItems={items}
      />

      {/* ===== Bag Panel (shown when "Borsa" is clicked) ===== */}
      <SaoPanel
        open={showBagPanel}
        onClose={() => setShowBagPanel(false)}
        title="Borsa"
        mode="bag"
        items={items.filter((i) => i.location === 'bag')}
        equipment={equipment}
        onEquip={handleEquip}
        onMoveToBag={handleMoveToBag}
        onMoveToInventory={handleMoveToInventory}
      />

      {/* ===== Inventory Panel (shown when "Inventario" is clicked) ===== */}
      <SaoPanel
        open={showInventoryPanel}
        onClose={() => setShowInventoryPanel(false)}
        title="Inventario"
        mode="inventory"
        items={items}
        equipment={equipment}
        onEquip={handleEquip}
        onMoveToBag={handleMoveToBag}
        onMoveToInventory={handleMoveToInventory}
      />

      {/* ===== Floor Panel (shown when "Piano" is clicked) ===== */}
      <FloorPanel
        open={showFloorPanel}
        onClose={() => setShowFloorPanel(false)}
        onZoneSelect={(zoneId) => {
          if (zoneId === 'starting-plains') {
            setShowFloorPanel(false);
            setExploreAreaId('grandi-pianure');
            setShowExplorePanel(true);
          } else if (zoneId === 'city-of-beginnings') {
            pushNotification({
              kind: 'system',
              title: 'Città degli Inizi',
              body: 'Benvenuto alla Città degli Inizi. Lo shop e gli NPC saranno disponibili in futuro.',
            });
          }
        }}
      />

      {/* ===== Explore Panel (shown when "Pianure dell'inizio" is clicked) ===== */}
      {/* Error Boundary: contiene errori runtime dell'esplorazione senza far crashare l'intera app */}
      <ExploreErrorBoundary>
      <ExplorePanel
        open={showExplorePanel}
        onClose={() => setShowExplorePanel(false)}
        areaId={exploreAreaId}
        items={items}
        equipment={equipment}
        onMoveToBag={handleMoveToBag}
        onMoveToInventory={handleMoveToInventory}
        onEquip={handleEquip}
        onUnequip={(slot) => {
          setEquipment((prev) => ({ ...prev, [slot]: null }));
          play('click', 0.4);
        }}
        cheats={cheats}
        playerStats={{
          STR: stats.str,
          DEX: stats.dex,
          AGI: stats.agi,
          VIT: stats.vit,
          RES: stats.res,
          MEN: stats.men,
          INT: stats.int,
        }}
        hp={hp}
        mp={mp}
        energy={energy}
        level={level}
        playerName={playerName}
        onItemFound={(itemId) => {
          // Add found item to inventory
          setItems((prev) => {
            const existing = prev.find((i) => i.id === itemId);
            if (existing) return prev; // already have it
            const sample = SAMPLE_ITEMS.find((i) => i.id === itemId);
            if (!sample) return prev;
            return [...prev, { ...sample, location: 'inventory', acquiredAt: Date.now() }];
          });
        }}
        onRest={() => {
          // Terminal rest: restore HP/MP/Energy to max
          setHp({ current: maxHp, max: maxHp });
          setMp({ current: maxMp, max: maxMp });
          setEnergy({ current: maxSp, max: maxSp });
        }}
      />
      </ExploreErrorBoundary>

      {/* ===== Journal Panel (Diario) ===== */}
      <JournalPanel
        open={showJournalPanel}
        onClose={() => setShowJournalPanel(false)}
        items={items}
      />
    </motion.div>
  );
}
